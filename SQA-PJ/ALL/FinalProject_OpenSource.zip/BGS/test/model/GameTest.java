package model;

import static model.Suit.*;
import static org.hamcrest.CoreMatchers.is;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class GameTest {

    public GameTest() {
    }


    @Test
    public void PlyerWin() {
    	System.out.println("TS001 Player Win");
        Player testPlayer = new Player("Player", "123");
        Hand testDealer = new Hand();
        int playerValue = 0;
        int dealerValue = 0;
        Game instance = new Game(testPlayer);
        Card[] playerCards = new Card[11];
        Card[] dealerCards = new Card[11];
        
        //PlayerScore more than Dealer Score ,PlayerScore less than 21   
        playerCards[0] = new Card(9, Spades);      //player cards
        playerCards[1] = new Card(9, Hearts);
        playerCards[2] = new Card(2, Diamonds);
        instance.getPlayer().getCurrentHand().setCardsDebug(playerCards);

        dealerCards[0] = new Card(6, Spades);      //dealer cards
        dealerCards[1] = new Card(6, Hearts);
        dealerCards[2] = new Card(3, Diamonds);
        testDealer.setCardsDebug(dealerCards);
        instance.setDealerDebug(testDealer);

        playerValue = instance.getPlayer().getCurrentHand().playerHandValue();  //check value using breakpoint
        dealerValue = instance.getDealer().dealerHandValue();                   //check value using breakpoint

        boolean expResult1 = true;    
        boolean result1 = instance.whoWon();
        assertEquals(expResult1, result1);
        
        //Dealer Score more than 21, PlayerScore lessthan 21                           
        playerCards[0] = new Card(4, Spades);      //player cards
        playerCards[1] = new Card(4, Hearts);
        playerCards[2] = new Card(4, Diamonds);
        instance.getPlayer().getCurrentHand().setCardsDebug(playerCards);

        dealerCards[0] = new Card(9, Spades);      //dealer cards
        dealerCards[1] = new Card(9, Hearts);
        dealerCards[2] = new Card(9, Diamonds);
        testDealer.setCardsDebug(dealerCards);
        instance.setDealerDebug(testDealer);

        playerValue = instance.getPlayer().getCurrentHand().playerHandValue();  //check value using breakpoint
        dealerValue = instance.getDealer().dealerHandValue();                   //check value using breakpoint

        boolean expResult2 = true;  
        boolean result2 = instance.whoWon();
        assertEquals(expResult2, result2);
        
        //PlayerScore equal 21 (BlackJack), DealerScore less than 21                   
        playerCards[0] = new Card(8, Spades);      //player cards
        playerCards[1] = new Card(8, Hearts);
        playerCards[2] = new Card(5, Diamonds);
        instance.getPlayer().getCurrentHand().setCardsDebug(playerCards);

        dealerCards[0] = new Card(4, Spades);      //dealer cards
        dealerCards[1] = new Card(4, Hearts);
        dealerCards[2] = new Card(4, Diamonds);
        testDealer.setCardsDebug(dealerCards);
        instance.setDealerDebug(testDealer);

        playerValue = instance.getPlayer().getCurrentHand().playerHandValue();  //check value using breakpoint
        dealerValue = instance.getDealer().dealerHandValue();                   //check value using breakpoint

        boolean expResult3 = true;  
        boolean result3 = instance.whoWon();
        assertEquals(expResult3, result3);
        
        //PlayerScore equal 21 (BlackJack), DealerScore more than 21                   
        playerCards[0] = new Card(8, Spades);      //player cards
        playerCards[1] = new Card(8, Hearts);
        playerCards[2] = new Card(5, Diamonds);
        instance.getPlayer().getCurrentHand().setCardsDebug(playerCards);

        dealerCards[0] = new Card(9, Spades);      //dealer cards
        dealerCards[1] = new Card(9, Hearts);
        dealerCards[2] = new Card(9, Diamonds);
        testDealer.setCardsDebug(dealerCards);
        instance.setDealerDebug(testDealer);

        playerValue = instance.getPlayer().getCurrentHand().playerHandValue();  //check value using breakpoint
        dealerValue = instance.getDealer().dealerHandValue();                   //check value using breakpoint

        boolean expResult4 = true;  
        boolean result4 = instance.whoWon();
        assertEquals(expResult4, result4);           	
    }
    
    @Test
    public void PlyerLoss() {
    	System.out.println("TS002 Player Lose");
        Player testPlayer = new Player("Player", "123");
        Hand testDealer = new Hand();
        int playerValue = 0;
        int dealerValue = 0;
        Game instance = new Game(testPlayer);
        Card[] playerCards = new Card[11];
        Card[] dealerCards = new Card[11];
        
      //DealScore more than Player Score ,DealerScore less than 21                       
        playerCards[0] = new Card(5, Spades);      //player cards
        playerCards[1] = new Card(5, Hearts);
        playerCards[2] = new Card(5, Diamonds);
        instance.getPlayer().getCurrentHand().setCardsDebug(playerCards);

        dealerCards[0] = new Card(6, Spades);      //dealer cards
        dealerCards[1] = new Card(6, Hearts);
        dealerCards[2] = new Card(6, Diamonds);
        testDealer.setCardsDebug(dealerCards);
        instance.setDealerDebug(testDealer);

        playerValue = instance.getPlayer().getCurrentHand().playerHandValue();  //check value using breakpoint
        dealerValue = instance.getDealer().dealerHandValue();                   //check value using breakpoint

        boolean expResult1 = false;  
        boolean result1 = instance.whoWon();
        assertEquals(expResult1, result1);
        
        //Player Score more than 21, DealerScore lessthan 21                          
        playerCards[0] = new Card(9, Spades);      //player cards
        playerCards[1] = new Card(9, Hearts);
        playerCards[2] = new Card(9, Diamonds);
        instance.getPlayer().getCurrentHand().setCardsDebug(playerCards);

        dealerCards[0] = new Card(6, Spades);      //dealer cards
        dealerCards[1] = new Card(6, Hearts);
        dealerCards[2] = new Card(6, Diamonds);
        testDealer.setCardsDebug(dealerCards);
        instance.setDealerDebug(testDealer);

        playerValue = instance.getPlayer().getCurrentHand().playerHandValue();  //check value using breakpoint
        dealerValue = instance.getDealer().dealerHandValue();                   //check value using breakpoint

        boolean expResult2 = false;  
        boolean result2 = instance.whoWon();
        assertEquals(expResult2, result2);
        
        //DealerScore equal 21 (BlackJack), PlayerScore less than 21                          
        playerCards[0] = new Card(6, Spades);      //player cards
        playerCards[1] = new Card(6, Hearts);
        playerCards[2] = new Card(6, Diamonds);
        instance.getPlayer().getCurrentHand().setCardsDebug(playerCards);

        dealerCards[0] = new Card(7, Spades);      //dealer cards
        dealerCards[1] = new Card(7, Hearts);
        dealerCards[2] = new Card(7, Diamonds);
        testDealer.setCardsDebug(dealerCards);
        instance.setDealerDebug(testDealer);

        playerValue = instance.getPlayer().getCurrentHand().playerHandValue();  //check value using breakpoint
        dealerValue = instance.getDealer().dealerHandValue();                   //check value using breakpoint

        boolean expResult3 = false;  
        boolean result3 = instance.whoWon();
        assertEquals(expResult3, result3);
        
        //DealerScore equal 21 (BlackJack), PlayerScore more than 21                          
        playerCards[0] = new Card(9, Spades);      //player cards
        playerCards[1] = new Card(9, Hearts);
        playerCards[2] = new Card(9, Diamonds);
        instance.getPlayer().getCurrentHand().setCardsDebug(playerCards);

        dealerCards[0] = new Card(7, Spades);      //dealer cards
        dealerCards[1] = new Card(7, Hearts);
        dealerCards[2] = new Card(7, Diamonds);
        testDealer.setCardsDebug(dealerCards);
        instance.setDealerDebug(testDealer);

        playerValue = instance.getPlayer().getCurrentHand().playerHandValue();  //check value using breakpoint
        dealerValue = instance.getDealer().dealerHandValue();                   //check value using breakpoint

        boolean expResult4 = false;  
        boolean result4 = instance.whoWon();
        assertEquals(expResult4, result4);
        
    }
    @Test
    public void Draw() {
    	System.out.println("TS003 Draw");
        Player testPlayer = new Player("Player", "123");
        Hand testDealer = new Hand();
        int playerValue = 0;
        int dealerValue = 0;
        Game instance = new Game(testPlayer);
        Card[] playerCards = new Card[11];
        Card[] dealerCards = new Card[11];
        

       // DealerScore equal PlayerScore, Both score are less than 21         
        playerCards[0] = new Card(5, Spades);      //player cards
        playerCards[1] = new Card(4, Hearts);
        playerCards[2] = new Card(3, Diamonds);
        instance.getPlayer().getCurrentHand().setCardsDebug(playerCards);

        dealerCards[0] = new Card(3, Spades);      //dealer cards
        dealerCards[1] = new Card(4, Hearts);
        dealerCards[2] = new Card(5, Diamonds);
        testDealer.setCardsDebug(dealerCards);
        instance.setDealerDebug(testDealer);

        playerValue = instance.getPlayer().getCurrentHand().playerHandValue();  //check value using breakpoint
        dealerValue = instance.getDealer().dealerHandValue();                   //check value using breakpoint

        boolean expResult1 = false;  
        boolean result1 = instance.whoWon();
        assertEquals(expResult1, result1);
        
        
     // DealerScore equal PlayerScore, Both score are more than 21
        playerCards[0] = new Card(10, Spades);      //player cards
        playerCards[1] = new Card(9, Hearts);
        playerCards[2] = new Card(8, Diamonds);
        instance.getPlayer().getCurrentHand().setCardsDebug(playerCards);

        dealerCards[0] = new Card(8, Spades);      //dealer cards
        dealerCards[1] = new Card(9, Hearts);
        dealerCards[2] = new Card(10, Diamonds);
        testDealer.setCardsDebug(dealerCards);
        instance.setDealerDebug(testDealer);

        playerValue = instance.getPlayer().getCurrentHand().playerHandValue();  //check value using breakpoint
        dealerValue = instance.getDealer().dealerHandValue();                   //check value using breakpoint

        boolean expResult2 = false;  
        boolean result2 = instance.whoWon();
        assertEquals(expResult2, result2);
        
        // Both BackJack(Both Score equal 21)
        playerCards[0] = new Card(10, Spades);      //player cards
        playerCards[1] = new Card(9, Hearts);
        playerCards[2] = new Card(2, Diamonds);
        instance.getPlayer().getCurrentHand().setCardsDebug(playerCards);

        dealerCards[0] = new Card(8, Spades);      //dealer cards
        dealerCards[1] = new Card(9, Hearts);
        dealerCards[2] = new Card(4, Diamonds);
        testDealer.setCardsDebug(dealerCards);
        instance.setDealerDebug(testDealer);

        playerValue = instance.getPlayer().getCurrentHand().playerHandValue();  //check value using breakpoint
        dealerValue = instance.getDealer().dealerHandValue();                   //check value using breakpoint

        boolean expResult3 = false;  
        boolean result3 = instance.whoWon();
        assertEquals(expResult3, result3);
        
    }

}
