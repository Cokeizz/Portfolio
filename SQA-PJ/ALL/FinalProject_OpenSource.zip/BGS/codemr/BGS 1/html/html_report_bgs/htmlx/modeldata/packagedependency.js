var matrix = [[0,0,0,0,0,0],[0,0,1,4,5,0],[0,1,0,1,0,0],[0,0,0,0,3,0],[0,0,0,0,0,1],[0,0,0,0,0,0]]
var packages = [{
"name": " ", "color": " #3182bd"
}
,{
"name": " view", "color": " #6baed6"
}
,{
"name": " controller", "color": " #9ecae1"
}
,{
"name": " model", "color": " #c6dbef"
}
,{
"name": " utilities", "color": " #e6550d"
}
,{
"name": " exceptions", "color": " #fd8d3c"
}
];
