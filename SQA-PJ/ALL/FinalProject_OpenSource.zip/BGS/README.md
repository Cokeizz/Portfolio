Blackjack Game System
===

University of Haifa: Software Engineering and Software Quality Assurance - Blackjack Game System

The BGS allows users to play an unlimited number of games for fun or for live betting, the system consists from standard blackjack rules. Users can take their own strategies in order to win the game. A game will always have a dealer and at least one opponent. The system supports scoring system for converting points to real cash or for fun purposes only. It also supports the most regular blackjack's functionality like "Hit", "Stand", etc…
The system will notify the user of his advancement during the game by on-screen notifications.
